<section class="festival"> 
            <h3>Fleurs d’oranger & chats errants  est nominé aux Oscars Short Film Animated de 2022 !</h3>
            <img class="oscars" src="/wp-content/themes/foce-child/assets/image/18-courts-metrages-francais-d-animation-eligibles-aux-oscars-2021.png">
            <img class="festival_background" src="/wp-content/themes/foce-child/assets/image/orange_characters_bg.png">
            <img class="festivalSunFlower" src="/wp-content/themes/foce-child/assets/image/Sunflower.png">
            <img class="festivalOrchid" src="/wp-content/themes/foce-child/assets/image/menu/Orchid.png">
        </section>